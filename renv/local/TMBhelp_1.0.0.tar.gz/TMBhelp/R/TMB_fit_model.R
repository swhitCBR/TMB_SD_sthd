
#' Title
#'
#' @param OBJ_in TMB ADobj for minimization
#' @param profile_CIs logical, calculate profile likelihood confidence intervals of fixed effects, not advised for mixed models at this time
#' @param OPT_control_args not working, options list for `nlminb`
#' @param dig_chce significant digits and rounding of parenthetical SEs
#' @param calc_SEs logical, calculate SE (run `TMB::sdreport`)
#' @param silent prints messages about model being fit, et
#' @param start_params starting values for parameters
#'
#' @returns named list of model outputs. When `calc_SEs = TRUE` this includes
#'   `COV_mat`, the `TMB::sdreport()` object with the joint precision matrix
#'   (see [get_COV_mat()]).
#' @export
#'
TMB_fit_model <- function(
    OBJ_in,
    profile_CIs=FALSE,
    OPT_control_args,
    dig_chce=2,
    calc_SEs=TRUE,
    silent=TRUE,
    start_params=NULL) {

  if(is.null(OPT_control_args)){
    # OPT_control_args=list(iter.max=1000,eval.max=10000)
    OPT_control_args=list(iter.max=10,eval.max=10)
  }

  if(is.null(start_params)){
    start_params <- OBJ_in$par
  }

  # getting model name from environment
  cpp_name=rlang::env_get(env = OBJ_in$env,nm = "DLL")
  if(!silent) message("fitting: ",cpp_name)
  map_in=rlang::env_get(env = OBJ_in$env,nm = "map")

  # print(OBJ_in$par)
  # start_params <- OBJ_in$par
  # Optimizing
  bt=proc.time()
  OPT = stats::nlminb( start=start_params,#start=OBJ_in$par,
                objective=OBJ_in$fn,
                gradient=OBJ_in$gr,
                control = OPT_control_args#,
                # control=list(iter.max=10,eval.max=10)
                )
  OPT
  OPT_secs <- round((proc.time()-bt)[3])
  names(OPT_secs)=NULL

  if(OPT$convergence!=0) {
    warning(paste0("model did not converge: ",message(OPT$message),"\nreturning OPT object"))
    print(OPT)
    return(OPT)
    }

  est_tab <- get_ests_tab(OBJ_in = OBJ_in,OPT_in = OPT,with_profCIs = profile_CIs,verbose=FALSE,calc_SEs =calc_SEs )

  RELGRP_err_v <- OBJ_in$report()$RELGRP_err
  # est_out_full <- summary(TMB::sdreport(OBJ_in,skip.delta.method = T))

  times_out=c(OPT_secs,
              est_tab$"times_out"["SD_secs"],
              est_tab$"times_out"["profCI_secs"])

  nll=OPT$objective
  k=length(OPT$par)
  AIC_mod <- 2*nll + 2*k

  if(calc_SEs){
  RE_tab <- get_DERIV_EST_tab(OBJ_in=OBJ_in,OPT_in=OPT,with_profCIs=FALSE,verbose=FALSE,calc_SEs=TRUE,silent=silent)
  COV_mat <- get_COV_mat(OBJ_in = OBJ_in, OPT_in = OPT)

  out_ls <- list(
    list(
      "OPT"=OPT,
      "est_tab"=est_tab,
      "time"=times_out,
      "k"=k,
      "nll"=nll,
      "AIC"=AIC_mod,
      "RE_tab"=RE_tab,
      "COV_mat"=COV_mat,
      "RELGRP_err_v"=RELGRP_err_v
    ))
  names(out_ls)[1] <- cpp_name # assigning model name

  return(out_ls)
  }

  out_ls <- list(
    list(
      "OPT"=OPT,
      # "est_tab"=est_tab,
      "time"=times_out,
      "k"=k,
      "nll"=nll,
      "AIC"=AIC_mod,
      "RELGRP_err_v"=RELGRP_err_v
    ))

  # "RE_relgrp_tab"=RE_tab[rownames(RE_tab[,"Estimate"])=="Sigma_RELGRP",],
  # "Sigma_RELGRP"=RE_tab[!rownames(RE_tab[,"Estimate"])=="Sigma_RELGRP",]

  names(out_ls)[1] <- cpp_name # assigning model name

  return(out_ls)

}
