#' Title
#'
#' @param cpp_name name of TMB model (excluding file extensions: .cpp,.dll,.o)
#' @param dir_in directory with model
#' @param silent logical. print messages during execution
#'
#' @returns NULL. Writes 'source()-able' script to file
#' @export
#'
sink_TMB_R_NORE <- function(cpp_name,dir_in,silent){
  sink( file.path(dir_in,paste0(cpp_name,".R") ))
  cat("
      library( TMB )
      setwd('",dir_in,"')
      dyn.load( TMB::dynlib('",cpp_name,"') )
      load( '",cpp_name,"_inputs.RData' )
      OBJ = MakeADFun(data=",cpp_name,"_inputs[['data']], parameters=",cpp_name,"_inputs[['parameters']],silent=",silent
      # ,",random='",random
      # ,"',inner.control = list(maxit=20000))
      ,",inner.control = list(maxit=20000))
      saveRDS(OBJ,'",cpp_name,"_OBJ.rds')\n",fill=FALSE,sep="")
  sink()
}


#' Title
#'
#' @param cpp_name name of TMB model (excluding file extensions: .cpp,.dll,.o)
#' @param dir_in directory with model
#' @param silent logical. print messages during execution
#' @param random random effect argument
#'
#' @returns NULL. Writes 'source()-able' script to file
#' @export
#'
sink_TMB_R <- function(cpp_name,dir_in,silent,random){
  sink( file.path(dir_in,paste0(cpp_name,".R") ))
  cat("
      library( TMB )
      setwd('",dir_in,"')
      dyn.load( TMB::dynlib('",cpp_name,"') )
      load( '",cpp_name,"_inputs.RData' )
      OBJ = MakeADFun(data=",cpp_name,"_inputs[['data']], parameters=",cpp_name,"_inputs[['parameters']],silent=",silent,",random='",random,"',inner.control = list(maxit=20000))
      saveRDS(OBJ,'",cpp_name,"_OBJ.rds')\n",fill=FALSE,sep="")
  sink()
}
