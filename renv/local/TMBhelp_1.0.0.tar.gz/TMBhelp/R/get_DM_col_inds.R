#' @title Lookup column IDs for a design matrix
#'
#' @description
#' Convert design matrix string into numeric vector of column indices
#'
#'
#' @param DM_string character string of length 1
#'
#' @returns integer vector of the columns tat match
#' @export
#'
get_DM_col_inds <- function(DM_string){
  # convert design matrix string into numeric vector
  inclu_TF <- as.numeric(strsplit(DM_string,"")[[1]])!=0
  which(inclu_TF)
}
