#' Title
#'
#' @param OBJ_in TMB object (made using `TMB::MakeADFun()`)
#' @param OPT_in result of optimization
#' @param with_profCIs logical, whether to calculate profile likelihood intervals (not recommended for mixed models at this time)
#' @param digits integer, indicating rounding or significant digits
#' @param verbose logical, display additional output
#' @param calc_SEs logical, calculate SEs (run `TMB::sdreport()`)
#' @param silent logical, print messages during execution
#'
#' @returns  dataframe of fixed and derived estimates
#' @export
#'
get_ests_tab <- function(OBJ_in,
                         OPT_in,
                         with_profCIs=TRUE,
                         digits=3,
                         verbose=FALSE,
                         calc_SEs=TRUE,
                         silent=TRUE){

  dig_chce=digits

  times_out=c(NA,NA)
  est_tab <- data.frame(Parameter=names(OPT_in$par),
                        Estimate_SE=round(OPT_in$par,digits=dig_chce))

  if(calc_SEs){
    bt=proc.time()
    out_w_RE <- get_SE(OBJ_in=OBJ_in,silent=silent)

    # out <- out_w_RE[match(names(OPT_in$par),rownames(out_w_RE)),]
    out <- out_w_RE[(rownames(out_w_RE) %in% names(OPT_in$par)),]
    # print(out_w_RE[!(rownames(out_w_RE) %in% names(OPT_in$par)),])
    # print(out_w_RE)
    # outDERIV <- out_w_RE[!(rownames(out_w_RE) %in% names(OPT_in$par)),]
    # print(out)



    SD_secs <- round((proc.time()-bt)[3])
    if(all((OPT_in$par-out[,1])!=0)){"OPT_in and OBJ_in parameter estimates do not match"}

    if(SD_secs>60){  message(paste("\nHessian inversion took ",SD_secs/60," minutes")) }

    profCI_secs=NA
    if(with_profCIs){
      bt=proc.time()
      profCI_tab <- get_TMB_prof_CIs(OBJ_in) # takes about 2 minutes
      profCI_secs <- round((proc.time()-bt)[3])
      names(profCI_secs)=NULL
      if(profCI_secs>30){  message(paste("\nProfiling took ",signif(profCI_secs/60,x = 3)," minutes")) }

      profCI_tab2 <- matrix(as.numeric(
        t(apply(profCI_tab[,-c(1)],1,digit_rf,digits=dig_chce))),ncol=2)
      colnames(profCI_tab2)=c("LCL","UCL")
      est_tab <- data.frame(paren_comb_tab(out,digits=dig_chce,col_nms = c("Parameter","Estimate_SE"),rw_nms = names(OPT_in$par)),
                            # out,
                            profCI_tab2)
    } else{
      est_tab <- data.frame(
        paren_comb_tab(out,digits=dig_chce,col_nms = c("Parameter","Estimate_SE"),
                       # out,
                                           rw_nms = names(OPT_in$par),silent=silent)
        )
    }

    est_tab <- data.frame(est_tab,out)

    if(!verbose) return(est_tab)

    times_out=c(SD_secs,profCI_secs)
  }

  # Parameter  Estimate_SE

  # names(times_out) <- c("SD_secs","profCI_secs")
  # verb_out <- list("times_out"=times_out,
  #                  "est_tab"=est_tab)
  # return(verb_out)
  return(est_tab)
}



