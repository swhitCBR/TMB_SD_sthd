#' Title
#'
#' @param OBJ_in TMB object
#' @param silent logical, print messages during execution
#'
#' @returns output table from `TMB::sdreport`
#' @export
#'
get_SE <- function(OBJ_in,silent=FALSE) {
  if(!silent){message("\ncomputing SEs")}
  summary(TMB::sdreport(OBJ_in))
}



