# estimates and SEs and parentheses
#' Title
#'
#' @param tab_in input dataframe
#' @param col_cmb integer string of columns to combin
#' @param digits rounding and significant ditigs
#' @param rw_nms optional row index
#' @param col_nms optional column index
#' @param silent logical, print messages during execution
#'
#' @returns character string with estimates and SE in parentheses
#' @export
#'
paren_comb_tab <- function(tab_in,col_cmb=1:2,digits=2,rw_nms=NULL,col_nms=NULL,silent=FALSE){
  if(!silent){ message("formatting numeric output")}
  if(is.null(rw_nms)) rw_nms=rownames(tab_in)
  if(is.null(col_nms)) col_nms=c("Parameter","Estimate (SE)")
  tmp1=sapply(1:nrow(tab_in),function(ii){
    y=digit_rf(tab_in[ii,col_cmb],digits)
    paste0(y[1]," (",y[2],")")})
  rownames(tmp1)
  if(ncol(tab_in)==2)  out= data.frame(rw_nms,tmp1)
  else(out=data.frame(rw_nms,tmp1,tab_in[,-c(col_cmb)]))
  rownames(out)=NULL; names(out)=col_nms
  return(out)
}
