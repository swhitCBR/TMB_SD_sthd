#' Joint covariance information for a fitted TMB model
#'
#' @description
#' Runs `TMB::sdreport()` with bias correction and the joint precision matrix.
#' The joint precision matrix includes random effects, so invert it with
#' `solve(out$jointPrecision)` to get the joint covariance matrix.
#'
#' @param OBJ_in TMB objective function (made by `TMB::MakeADFun()`)
#' @param OPT_in output of `nlminb()` from fitting `OBJ_in`; not used in the
#'   calculation, kept for consistency with the other extraction functions
#'
#' @returns an `sdreport` object
#' @export
#'
get_COV_mat <- function(OBJ_in, OPT_in = NULL) {
  TMB::sdreport(OBJ_in,
                bias.correct = TRUE,
                getJointPrecision = TRUE,
                skip.delta.method = FALSE)
}
