#' Title
#' @description
#' Wrapper function for TMB_model_setup()
#'
#' @param TMB_data_baseline_in named list of TMB model inputs variable matching template
#' @param cpp_name_in template file, excludding file extentions e.g.,(.cpp,.o,.dll)
#' @param dir_in directory containing template
#' @param OPT_control_args not working, but intended to pass list of `nlminb` arg
#' @param calc_SEs logical, whether to invert covariance matrix (run `TMB::sdreport`)
#' @param start_params numeric vector of starting variables
#' @param silent logica, print messages during execution
#' @param OBJ_in TMB objective function (made by running `TMB:MakeADFun()`)
#'
#' @returns named list of multiple model objects
#'
tmb_setup_and_fit <- function(
    TMB_data_baseline_in=NULL,
    cpp_name_in = NULL,
    dir_in=getwd(),
    OBJ_in=NULL,
    OPT_control_args=NULL,
    calc_SEs=FALSE,
    start_params=NULL,
    silent=F){

  if(dir_in==getwd()){message("using .cpp and .dll in working directory")}

  # initial values of detection probability
  P_mat_base_input <- matrix(0,nrow=length(TMB_data_baseline_in$col_P11),
                             ncol=TMB_data_baseline_in$P_lc_n)
  S_pars_input <- rep(0,ncol(TMB_data_baseline_in$XX_s))


  if(is.null(OPT_control_args)){
    OPT_control_args=list(iter.max=1000,eval.max=10000)
    # print("ha")
  }


  # if(){
  #   message("setting up model files from scratch")
  OBJ_tmp <- TMB_model_setup(
      cpp_name = cpp_name_in,
      dir_in = dir_in,
      data=TMB_data_baseline_in,
      parameters=list(
        "S_pars"=S_pars_input,
        "RELGRP_err"=rep(0,TMB_data_baseline_in$n_relgrps),
        "logSD_RELGRP"=log(1),
        "P_pars"=P_mat_base_input),
      random=c("RELGRP_err"),
      recompile=F,
      overwrite=F,
      check_Eigen=F,
      check_differen = F,
      silent = T
    )
  # }

  indiv_mod <- TMB_fit_model(OBJ_in = OBJ_tmp,
                             profile_CIs = F,
                             calc_SEs=calc_SEs,
                             OPT_control_args = OPT_control_args,
                             silent=silent,
                             start_params=start_params)

  return(indiv_mod)

}

