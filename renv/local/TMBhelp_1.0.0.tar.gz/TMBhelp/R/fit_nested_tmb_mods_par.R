#' Fit nested TMB models in parallel
#'
#' @description
#' Parallel, file-free alternative to [fit_nested_tmb_mods()]. Each worker
#' process loads the compiled template once and builds the AD object in memory
#' with `TMB::MakeADFun()`, so no `<cpp>.R`, `_inputs.RData` or `_OBJ.rds` files
#' are written and nothing is `source()`d into the global environment. Models
#' are dispatched one at a time, those with the most terms first.
#'
#' The template must already be compiled (`.dll`/`.so` in `dir_in`). Shut down
#' any clusters before calling `TMB::compile()`.
#'
#' @inheritParams fit_nested_tmb_mods
#' @param n_workers number of worker processes
#' @param pkg_path optional path to the TMBhelp source. When supplied, workers
#'   use `devtools::load_all(pkg_path)` instead of the installed package
#'   (for development)
#'
#' @returns named list (names = design strings). Converged fits have the same
#'   elements as [fit_nested_tmb_mods()] plus `converged = TRUE` and
#'   `wall_secs`. Failed or non-converged fits return a list with
#'   `converged = FALSE`, `message`, `nll` and `wall_secs`. The `timing`
#'   attribute has start-up, fitting and total seconds.
#' @export
#'
fit_nested_tmb_mods_par <- function(
    S_design_matrix_in,
    TMB_data_baseline_in,
    cpp_name_in,
    dir_in = getwd(),
    n_workers = 4,
    OPT_control_args = NULL,
    calc_SEs = FALSE,
    start_params_ls = NULL,
    silent = TRUE,
    pkg_path = NULL){

  if(!all(nchar(S_design_matrix_in) == ncol(TMB_data_baseline_in$"XX_s"))){
    stop("expects a character string of length >=1 with ",ncol(TMB_data_baseline_in$"XX_s")," 0s and 1s without spaces")
  }

  cfg <- list(cpp_name = cpp_name_in, dir_in = normalizePath(dir_in, mustWork = TRUE),
              OPT_control_args = OPT_control_args, calc_SEs = calc_SEs, silent = silent)
  load_pkg <- if(is.null(pkg_path)) quote(library(TMBhelp)) else
    bquote(devtools::load_all(.(normalizePath(pkg_path, mustWork = TRUE)), quiet = TRUE))

  t0 <- proc.time()[["elapsed"]]
  cl <- parallel::makePSOCKcluster(n_workers)
  on.exit(parallel::stopCluster(cl), add = TRUE)
  # one at a time so that package loading does not race
  for(i in seq_along(cl)) parallel::clusterCall(cl[i], eval, load_pkg, globalenv())
  parallel::clusterCall(cl, tmb_worker_init, cfg, TMB_data_baseline_in)
  t1 <- proc.time()[["elapsed"]]

  n <- length(S_design_matrix_in)
  tasks <- lapply(seq_len(n), function(i){
    list(design = S_design_matrix_in[i], start = start_params_ls[[i]])})
  # models with more terms tend to be slower
  ord <- order(-nchar(gsub("0", "", S_design_matrix_in)), seq_len(n))
  res <- parallel::parLapplyLB(cl, tasks[ord], tmb_worker_task, chunk.size = 1)

  ls_out <- vector("list", n)
  ls_out[ord] <- res
  names(ls_out) <- S_design_matrix_in
  t2 <- proc.time()[["elapsed"]]
  attr(ls_out, "timing") <- c(startup_secs = t1 - t0, fit_secs = t2 - t1,
                              total_secs = t2 - t0, n_workers = n_workers)
  ls_out
}

# per-worker storage for the shared config and data (sent once per worker)
.tmb_worker_env <- new.env()

tmb_worker_init <- function(cfg, TMB_data){
  dyn.load(TMB::dynlib(file.path(cfg$dir_in, cfg$cpp_name)))
  # avoid oversubscribing cores; harmless if the DLL was built without OpenMP
  try(suppressWarnings(TMB::openmp(1)), silent = TRUE)
  .tmb_worker_env$cfg <- cfg
  .tmb_worker_env$data <- TMB_data
  invisible(TRUE)
}

tmb_worker_task <- function(tk){
  cfg <- .tmb_worker_env$cfg
  dat <- .tmb_worker_env$data
  t0 <- proc.time()[["elapsed"]]

  inclu_IND <- which(strsplit(tk$design, "")[[1]] != "0")
  dat$"XX_s" <- dat$"XX_s"[, inclu_IND, drop = FALSE]
  if(!is.null(dat$"XX_pred_mat")){
    dat$"XX_pred_mat" <- dat$"XX_pred_mat"[, inclu_IND, drop = FALSE]
  }
  # same default as tmb_setup_and_fit()
  OPT_control_args <- cfg$OPT_control_args
  if(is.null(OPT_control_args)) OPT_control_args <- list(iter.max = 1000, eval.max = 10000)

  # same data, parameters, random and inner.control as the script from sink_TMB_R()
  res <- tryCatch({
    obj <- TMB::MakeADFun(
      data = dat,
      parameters = list(
        "S_pars" = rep(0, ncol(dat$"XX_s")),
        "RELGRP_err" = rep(0, dat$"n_relgrps"),
        "logSD_RELGRP" = log(1),
        "P_pars" = matrix(0, nrow = length(dat$"col_P11"), ncol = dat$"P_lc_n")),
      random = "RELGRP_err", DLL = cfg$cpp_name, silent = cfg$silent,
      inner.control = list(maxit = 20000))
    if(!is.null(tk$start) && length(tk$start) != length(obj$par)){
      stop("start_params has length ", length(tk$start),
           " but the model has ", length(obj$par), " parameters")
    }
    out <- NULL
    utils::capture.output(
      out <- suppressWarnings(TMB_fit_model(
        OBJ_in = obj, profile_CIs = FALSE, calc_SEs = cfg$calc_SEs,
        OPT_control_args = OPT_control_args, silent = cfg$silent,
        start_params = tk$start)))
    out
  }, error = function(e) e)

  secs <- proc.time()[["elapsed"]] - t0
  if(inherits(res, "error")){
    return(list(converged = FALSE, message = conditionMessage(res),
                nll = NA_real_, wall_secs = secs))
  }
  # TMB_fit_model() returns the raw nlminb result when the fit did not converge
  if("convergence" %in% names(res)){
    return(list(converged = FALSE, message = res$message,
                nll = res$objective, OPT = res, wall_secs = secs))
  }
  c(res[[1]], list(converged = TRUE, wall_secs = secs))
}
