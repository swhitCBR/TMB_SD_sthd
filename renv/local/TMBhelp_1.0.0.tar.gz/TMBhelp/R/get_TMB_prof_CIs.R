
#' Title
#'
#' @param ADfunOBJ TMB automatic differentiation object
#' @param par_ind integer index of parameter to profile
#' @param trace nth iteration to print
#' @param rw_nms row name
#' @param col_nms column name
#'
#' @returns dataframe of profiled estimates
#' @export
#'
get_TMB_prof_CIs <- function(ADfunOBJ,par_ind=NULL,trace=0,rw_nms=NULL,col_nms=NULL){
  if(is.null(col_nms)) col_nms=c("Parameter","LCL","UCL")
  if(is.null(par_ind)){
    par_ind=1:length(ADfunOBJ$par)
    message(paste("calculating 95% profile likelihood CIs for",length(par_ind))," parameters in 'par' vector")}
  npars=length(par_ind)

  cf_tmp1=NULL     # inefficient coding here (not good idea to recursively rbind)
  pb = utils::txtProgressBar(min = 0, max = length(ADfunOBJ$par), initial = 0)
  for(ii in 1:npars){
    utils::setTxtProgressBar(pb,ii)
    tmp_prf=TMB::tmbprofile(ADfunOBJ,par_ind[ii],trace=trace)
    cf_tmp1=rbind(cf_tmp1,
                  data.frame(suppressWarnings(stats::confint(tmp_prf))))
  }
  cf_tmp2=data.frame(names(ADfunOBJ$par),cf_tmp1)
  names(cf_tmp2)=col_nms
  rownames(cf_tmp2)=NULL
  return(cf_tmp2)
}
