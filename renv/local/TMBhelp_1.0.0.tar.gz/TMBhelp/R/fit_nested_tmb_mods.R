
#' Title
#'
#' @param S_design_matrix_in design matrix binary output
#' @param TMB_data_baseline_in named list of tmb data
#' @param cpp_name_in name of TMB template (does not include '.cpp' extension )
#' @param dir_in directory with model
#' @param calc_SEs logical, whether to calculate SE. SE calc takes longer
#' @param OPT_control_args not working, supply list of `options` to `nlminb()`
#' @param start_params_ls list of starting parameter
#' @param simplify argument to internal `sapply`
#' @param silent logical, print messages during execution
#'
#' @returns list of arrays with multple outputs for each model
#' @export
#'
fit_nested_tmb_mods<- function(
    S_design_matrix_in, # character string with 21 ones and zeros indicating variables
    TMB_data_baseline_in,
    cpp_name_in = NULL,
    dir_in = getwd(),
    OPT_control_args=NULL,
    calc_SEs=FALSE,
    simplify=FALSE,
    start_params_ls=NULL,
    silent=TRUE){

  if(!all(sapply(S_design_matrix_in,function(x) all(nchar(x)==ncol(TMB_data_baseline_in$"XX_s"))))){
    stop("expects a character string of length >=1 with ",ncol(TMB_data_baseline_in$"XX_s")," 0s and 1s without spaces")
  }

  ls10mods <- length(S_design_matrix_in)<20
  # tab_out <- sapply(1:length(S_design_matrix_in),function(x){
  ls_out <- sapply(1:length(S_design_matrix_in),function(x){
    if(ls10mods){ message(x," of ",length(S_design_matrix_in))} else{
      if (x %in% c(1,5,50,seq(100,1000,100))) message(x," of ",length(S_design_matrix_in))
    }

    inclu_TF <- as.numeric(strsplit(S_design_matrix_in[x],"")[[1]])!=0
    inclu_IND <- which(inclu_TF)

    # print(inclu_IND)

    TMB_data_tmp <- TMB_data_baseline_in
    TMB_data_tmp$"XX_s" <- TMB_data_tmp$"XX_s"[,inclu_IND]

    if(!is.null(TMB_data_tmp$"XX_pred_mat")){
      TMB_data_tmp$"XX_pred_mat" <- TMB_data_tmp$"XX_pred_mat"[,inclu_IND]
    }

    tmp <- #suppressWarnings(
      tmb_setup_and_fit(TMB_data_baseline_in=TMB_data_tmp,
                        cpp_name_in = cpp_name_in,
                        OPT_control_args=OPT_control_args,
                        dir_in = dir_in,
                        calc_SEs=calc_SEs,
                        start_params=start_params_ls[[x]],
                        silent=silent)[[1]] # extracting first item prevents redundant lists

    tmp

  },simplify = simplify)

  names(ls_out) <- S_design_matrix_in

  # tab_out2 <- t(tab_out)
  # tab_out3 <- data.frame(mod_DM=S_design_matrix_in,tab_out2)

  return(ls_out)

}
