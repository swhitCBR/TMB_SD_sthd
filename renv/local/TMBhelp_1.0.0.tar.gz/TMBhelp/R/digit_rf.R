# rounding digits
#' Title
#'
#' @param x numeric value to round
#' @param digits rounding/ significant digits
#'
#' @returns rounded version of estimate `sprintf(paste0("%.",digits,"f"), x)`
#' @export
#'
digit_rf <- function(x,digits){
  sprintf(paste0("%.",digits,"f"), x)}
