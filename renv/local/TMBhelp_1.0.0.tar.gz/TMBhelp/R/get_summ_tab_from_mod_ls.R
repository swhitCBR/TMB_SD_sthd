#' Title
#'
#' @param mod_ls_in named list output from `fit_nested_tmb_mods()`
#'
#' @returns dataframe summarizing model fits and nll and AIC
#' @export
#'
get_summ_tab_from_mod_ls <- function(mod_ls_in,rank_by="dAIC"){
  AIC_DF_tmp <- data.frame(
    dm=names(mod_ls_in)[1:length(mod_ls_in)],
    k=sapply(1:length(mod_ls_in),function(ii){mod_ls_in[[ii]]$"k"}),
    nll=sapply(1:length(mod_ls_in),function(ii){mod_ls_in[[ii]]$"nll"}),
    AIC=sapply(1:length(mod_ls_in),function(ii){mod_ls_in[[ii]]$"AIC"}),
    iterations=sapply(1:length(mod_ls_in),function(ii){mod_ls_in[[ii]]$OPT$"iterations"}),
    message=sapply(1:length(mod_ls_in),function(ii){mod_ls_in[[ii]]$OPT$"message"}))

  if(rank_by=="dAIC"){
    AIC_DF_tmp$dAIC=AIC_DF_tmp$AIC-min(AIC_DF_tmp$AIC)
    AIC_DF_tmp <- AIC_DF_tmp[order(AIC_DF_tmp$dAIC),]
  }

  AIC_DF_tmp
}
