# compile build and check model for errors and ability to differentiate with starting values
#' Title
#'
#' @param cpp_name TMB template name (excluding file extention)
#' @param data named list of data referenced in template
#' @param parameters parameter staring values
#' @param random random effects (should be a subset of `parameters`)
#' @param dir_in directory containing template file
#' @param overwrite logical, overwrite existing compilation files (maybe no longer working)
#' @param recompile logical, recompile model (i.e., replace existing .o and .dll files matching file name)
#' @param check_Eigen logical, check that there isn't a fatal flaw (i.e., causing R to shutdown) related dimension mismatch between template and input data
#' @param check_differen logical, check that objective function is differentiable at staring values
#' @param silent logical, print messages during execution
#' @param ... additional arguments passed to list object (kind of strange, probably not used)
#'
#' @returns AD objective function (produced by `TMB::MakeADFun()`)
#' @export
#'
TMB_model_setup = function( cpp_name, data, parameters, random=NULL,
                            dir_in=getwd(), overwrite=FALSE, recompile=TRUE,
                            check_Eigen=FALSE,check_differen,silent=TRUE,... ){

  # Set local working directory
  orig_dir = getwd()
  setwd( dir_in )
  on.exit( setwd(orig_dir) )

  dlls <- getLoadedDLLs()
  # does it produce an error


  comp_fls_exist <- all(paste0(cpp_name,c(".o")) %in% dir(dir_in) &
                          (paste0(cpp_name,c(".so")) %in% dir(dir_in) | paste0(cpp_name,c(".dll")) %in% dir(dir_in))
                        )
  if(!comp_fls_exist){
    recompile=TRUE
    message(paste0(".dll and .o files for ",cpp_name," absent from directory"))
    message("attempting to compile")}

  # length 0, character vector or length=1 character
  TMBdll <- sapply(dlls, isTMBdll)

  # load dll is all compilation files exist
  if(all(!TMBdll) & comp_fls_exist){
    dyn.load( TMB::dynlib(cpp_name) ); message(paste0("loaded ",cpp_name,".dll"))
  }

  # Recompile
  if( recompile==TRUE ){
    unlink( paste0(cpp_name,".o") )
    unlink( paste0(cpp_name,".dll") )
    unlink( paste0(cpp_name,".R") )
    TMB::compile( paste0(cpp_name,".cpp"), "-O1 -g", DLLFLAGS="")
  }


  if(is.null(random)){

    message("No random effects")

    # Get and save inputs
    Other_inputs = list(...)
    assign(x=paste0(cpp_name,"_inputs"),value=list( "data"=data, "parameters"=parameters, "random"=NULL, "Other_inputs"=Other_inputs ))
    save(list = paste0(cpp_name,"_inputs"), file=paste0(cpp_name,"_inputs.RData"))

    if(check_differen){
      orig_silent=silent
      silent=FALSE}

    sink_TMB_R_NORE(cpp_name,dir_in,silent=silent)

    if(check_Eigen){
      message("opening cmd prompt to debug eigen")
      Bdg_output = TMB::gdbsource(paste0(cpp_name,".R"),interactive = T)
      message("if there are no errors, close gdb command prompt entering 'q' and then rerun this function switching 'check_Eigen' to FALSE")
    }

    sink_TMB_R_NORE(cpp_name,dir_in,silent=silent)
    source(paste0(cpp_name,".R"))

    if(check_differen){
      if(is.na(OBJ$fn())){warning("non-differentiable objective function")}

      sink_TMB_R_NORE(cpp_name,dir_in,silent=silent)
      source(paste0(cpp_name,".R"))
    }
    OBJ <- readRDS(paste0(cpp_name,"_OBJ.rds"),)

    if(!silent) message("saving ADobj to model directory")

    return(OBJ)

  }

  # Get and save inputs
  Other_inputs = list(...)
  assign(x=paste0(cpp_name,"_inputs"),value=list( "data"=data, "parameters"=parameters, "random"=random, "Other_inputs"=Other_inputs ))
  save(list = paste0(cpp_name,"_inputs"), file=paste0(cpp_name,"_inputs.RData"))

  if(check_differen){
    orig_silent=silent
    silent=FALSE}

  sink_TMB_R(cpp_name,dir_in,silent=silent,random=random)

  if(check_Eigen){
    message("opening cmd prompt to debug eigen")
    Bdg_output = TMB::gdbsource(paste0(cpp_name,".R"),interactive = T)
    message("if there are no errors, close gdb command prompt entering 'q' and then rerun this function switching 'check_Eigen' to FALSE")
  }

  sink_TMB_R(cpp_name,dir_in,silent=silent,random=random)
  source(paste0(cpp_name,".R"))

  if(check_differen){
    if(is.na(OBJ$fn())){warning("non-differentiable objective function")}

    sink_TMB_R(cpp_name,dir_in,silent=orig_silent,random=random)
    source(paste0(cpp_name,".R"))
  }

  if(!silent) message("saving ADobj to model directory")

  return(OBJ)

}


