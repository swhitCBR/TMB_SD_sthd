#' Title
#'
#' @param OBJ_in TMB object (made using `TMB::MakeADFun()`)
#' @param OPT_in result of optimization
#' @param with_profCIs logical, whether to calculate profile likelihood intervals (not recommended for mixed models at this time)
#' @param verbose logical, display additional output
#' @param silent logical, print messages during execution
#' @param calc_SEs logical, calculate SEs (run `TMB::sdreport()`)
#'
#'
#' @returns dataframe of derived estimates
#' @export
#'
get_DERIV_EST_tab <- function(OBJ_in,OPT_in,with_profCIs=TRUE,verbose=FALSE,calc_SEs=TRUE,silent=FALSE
){
  if(calc_SEs){
    bt=proc.time()
    out_w_RE <- get_SE(OBJ_in=OBJ_in,silent=silent)

    out <- out_w_RE[(rownames(out_w_RE) %in% names(OPT_in$par)),]
    outDERIV <- out_w_RE[!(rownames(out_w_RE) %in% names(OPT_in$par)),]

    return(outDERIV)
  }
  return(NULL)
}
