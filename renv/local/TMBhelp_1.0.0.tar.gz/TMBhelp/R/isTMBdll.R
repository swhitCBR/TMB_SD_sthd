
#' Title
#'
#' @param dll name of .dll associated with TMB template
#'
#' @returns logical, indicating is variable is loaded
#' @export
#'
isTMBdll <- function(dll) {
  !methods::is(try(getNativeSymbolInfo("MakeADFunObject",dll), TRUE), "try-error")
}


