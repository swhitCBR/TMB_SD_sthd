# TMBhelp

## Known code issues (not yet fixed)

These were found while tracing `fit_nested_tmb_mods()` and its dependencies. They are left unchanged for now to avoid breaking existing code.

### Global environment and file side effects

- **`source()` evaluates in the global environment** (`R/TMB_model_setup.R`, the `source(paste0(cpp_name, ".R"))` calls). The generated script creates `OBJ` and `<cpp_name>_inputs` (via `load()`) in the global environment, and also calls `library(TMB)`, `setwd()` and `dyn.load()`. On the random-effects path, the returned `OBJ` is the global one. Possible fix: `source(..., local = TRUE)`, or read the saved `_OBJ.rds` as the no-random-effects path already does.
- **Not re-entrant / not parallel-safe.** Every model fit overwrites the same `<cpp_name>.R`, `<cpp_name>_inputs.RData`, `<cpp_name>_OBJ.rds` (in `dir_in`) and the global `OBJ`.
- **`sink()` is not protected** (`R/sink_TMB_R.R`). If an error occurs between `sink()` and `sink()` close, output stays diverted. Consider `on.exit(sink())` or `writeLines()` to a file instead.

### `TMB_model_setup()`

- `check_differen` has no default, so calling the function directly without it errors (`tmb_setup_and_fit()` always supplies it).
- `orig_silent` is only defined when `check_differen = TRUE`. This is currently safe because it is only used inside that branch.

### `TMB_fit_model()` / `get_ests_tab()`

- **Redundant `sdreport()` calls.** With `calc_SEs = TRUE`, `TMB::sdreport()` runs three times: via `get_ests_tab()` -> `get_SE()`, via `get_DERIV_EST_tab()` -> `get_SE()`, and in `get_COV_mat()` (with bias correction, the slowest). Computing it once and reusing the result would save time.
- **`times_out` lookup.** `get_ests_tab()` returns only `est_tab` (a data frame) when `verbose = FALSE`, but `TMB_fit_model()` reads `est_tab$"times_out"[...]`, which is `NULL` for a data frame, so the SD and profile timings are not recorded as intended.
- **No-op parameter check** (`R/get_ests_tab.R`): the line `"OPT_in and OBJ_in parameter estimates do not match"` is a bare string with no `warning()` or `stop()`, so the check never reports anything. The condition `all((OPT_in$par - out[,1]) != 0)` also looks inverted (it is TRUE only when *no* estimates match).
- **Non-convergence return type.** `TMB_fit_model()` returns the raw `nlminb` `OPT` object when the model does not converge. In `fit_nested_tmb_mods()` this then sits in the output list in place of the usual per-model list, so downstream code (e.g. `get_summ_tab_from_mod_ls()`) may fail on it.
- **`OPT_control_args` defaults differ** between `tmb_setup_and_fit()` (`iter.max = 1000, eval.max = 10000`) and `TMB_fit_model()` (`iter.max = 10, eval.max = 10`). The first default normally applies, but a direct call to `TMB_fit_model()` with `NULL` will cap optimisation at 10 iterations. The docs also say `OPT_control_args` is "not working" in several places.

### Resolved

- `get_ests_tab()` passed `silent = silent` into `data.frame()` in the profile-CI branch, creating a spurious `silent` column. Fixed.
